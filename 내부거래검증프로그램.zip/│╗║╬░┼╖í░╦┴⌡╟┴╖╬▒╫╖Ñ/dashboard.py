# -*- coding: utf-8 -*-
"""
Phase 4 - 내부거래검증 대시보드 (Streamlit).

본사 대사(src.reconcile) 결과와 법인간 거래 교차검증(src.intercompany) 결과를 각각
탭으로 보여준다. 각 탭에는 KPI, 법인(쌍) x 월 히트맵, 필터, 상세 테이블, AI 코멘트
패널을 둔다. xlsx 로딩과 대사 계산은 무거운 작업(Excel COM 구동 포함)이므로
st.cache_data로 캐싱해 위젯 조작 시마다 다시 계산하지 않도록 한다.
"""

import pandas as pd
import plotly.express as px
import streamlit as st

from src import reconcile as rc
from src import intercompany as ic
from src import report as rpt
from src import ai_comment as aic
from src import root_cause as rca
from src import masters as m

st.set_page_config(page_title="내부거래검증 대시보드", layout="wide")

_ACCOUNT_TYPE_LABEL = {"BS": "자산/부채", "PL": "수익/비용"}


def _add_account_type(df: pd.DataFrame) -> pd.DataFrame:
    df["계정유형"] = df["ACCT_CD"].map(lambda c: _ACCOUNT_TYPE_LABEL[m.classify_account(c)])
    return df


@st.cache_data(show_spinner="본사 대사 데이터 계산 중 (Excel 로딩)...")
def load_hq_data() -> pd.DataFrame:
    result = rc.run()
    df = rpt.add_classification(result)
    df = rca.add_causes(df, entity_col="법인명", account_col="계정명",
                         amt1_col="해외법인_KRW", amt2_col="본사_KRW")
    return _add_account_type(df)


@st.cache_data(show_spinner="법인간 거래 데이터 계산 중 (Excel 로딩)...")
def load_pair_data() -> pd.DataFrame:
    pair_result = ic.run()
    pair_df = ic.add_classification(pair_result)
    pair_df["법인쌍명"] = pair_df["법인1명"] + " - " + pair_df["법인2명"]
    pair_df = rca.add_causes(pair_df, entity_col="법인쌍명", account_col="계정명",
                              amt1_col="법인1_KRW", amt2_col="법인2_KRW")
    return _add_account_type(pair_df)


def yyyymm_label(v: int) -> str:
    y, m = divmod(int(v), 100)
    return f"{y}-{m:02d}"


def render_dashboard(df: pd.DataFrame, key: str, entity_col: str, entity_label: str,
                      amt1_col: str, amt1_label: str, amt2_col: str, amt2_label: str,
                      local1_col: str = None, local1_ccy_col: str = None,
                      local2_col: str = None, local2_ccy_col: str = None):
    months = sorted(df["YYYYMM"].unique())
    entities = sorted(df[entity_col].unique())
    account_types = sorted(df["계정유형"].unique())
    statuses = sorted(df["구분"].unique())

    with st.expander("필터", expanded=True):
        c1, c2 = st.columns(2)
        with c1:
            month_range = st.select_slider(
                "기간", options=months, value=(months[0], months[-1]),
                format_func=yyyymm_label, key=f"{key}_month",
            )
        with c2:
            status_sel = st.multiselect("구분", options=statuses, default=statuses, key=f"{key}_status")
        c3, c4 = st.columns(2)
        with c3:
            entity_sel = st.multiselect(f"{entity_label} 선택", options=entities, default=entities, key=f"{key}_entity")
        with c4:
            type_sel = st.multiselect("계정 구분", options=account_types, default=account_types, key=f"{key}_acct_type")
        accounts_in_type = sorted(df.loc[df["계정유형"].isin(type_sel), "계정명"].unique())
        # 계정 구분 선택이 바뀌면 위젯 key도 바뀌어 새로 초기화되도록 한다 (그렇지 않으면
        # 이전에 선택했던 계정이 좁혀진 옵션 목록에 없어서 위젯이 깨질 수 있음).
        account_key = f"{key}_account_" + "-".join(type_sel)
        account_sel = st.multiselect(
            "계정 선택", options=accounts_in_type, default=accounts_in_type, key=account_key,
        )

    fdf = df[
        (df["YYYYMM"] >= month_range[0]) & (df["YYYYMM"] <= month_range[1])
        & (df[entity_col].isin(entity_sel))
        & (df["계정유형"].isin(type_sel))
        & (df["계정명"].isin(account_sel))
        & (df["구분"].isin(status_sel))
    ]

    total = len(fdf)
    mismatched = int((fdf["구분"] != "일치").sum())
    match_rate = 1 - mismatched / total if total else 0.0
    total_abs_diff = fdf.loc[fdf["구분"] != "일치", "차이금액"].abs().sum()

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("총 조합 건수", f"{total:,}")
    k2.metric("일치율", f"{match_rate:.1%}")
    k3.metric("불일치 건수", f"{mismatched:,}")
    k4.metric("불일치 차이금액 합계(KRW)", f"{total_abs_diff:,.0f}")

    st.subheader(f"{entity_label} x 월 불일치 금액 히트맵")
    mism = fdf[fdf["구분"] != "일치"].copy()
    if len(mism):
        mism["_abs"] = mism["차이금액"].abs()
        top_entities = (
            mism.groupby(entity_col)["_abs"].sum().sort_values(ascending=False).head(20).index
        )
        pivot = (
            mism[mism[entity_col].isin(top_entities)]
            .pivot_table(index=entity_col, columns="YYYYMM", values="_abs", aggfunc="sum", fill_value=0)
        )
        pivot = pivot.reindex(index=top_entities)
        pivot.columns = [yyyymm_label(c) for c in pivot.columns]
        fig = px.imshow(
            pivot, aspect="auto", color_continuous_scale="Oranges",
            labels=dict(x="연월", y=entity_label, color="차이금액 절대값(KRW)"),
        )
        fig.update_layout(height=max(300, 24 * len(pivot)))
        st.plotly_chart(fig, width="stretch", key=f"{key}_heatmap")
        if len(entities) > 20:
            st.caption(f"불일치 금액 상위 20개 {entity_label}만 표시합니다 (전체 {len(entities)}개).")
    else:
        st.info("선택한 조건에서는 불일치 건이 없습니다.")

    st.subheader(f"{entity_label}별 내부거래 금액 추이")
    if len(fdf):
        # 본사측/해외법인측(또는 법인1측/법인2측)을 나눠 그리지 않는다 - 두 원장은 결국
        # 같은 거래를 각자 기표한 것이라 하나로 일치시킬 대상이므로, amt1_col 기준
        # 금액 하나만 법인별 라인으로 겹쳐 그린다.
        MAX_LINES = 12
        magnitude = fdf.groupby(entity_col)[amt1_col].apply(lambda s: s.abs().sum())
        trend_entities = magnitude.sort_values(ascending=False).head(MAX_LINES).index

        trend = (
            fdf[fdf[entity_col].isin(trend_entities)]
            .groupby([entity_col, "YYYYMM"], as_index=False)[amt1_col]
            .sum()
            .rename(columns={amt1_col: "금액"})
        )
        trend["연월"] = trend["YYYYMM"].map(yyyymm_label)
        trend = trend.sort_values("YYYYMM")

        fig_trend = px.line(
            trend, x="연월", y="금액", color=entity_col, markers=True,
            category_orders={entity_col: list(trend_entities)},
            labels={"금액": "금액(KRW)"},
        )
        fig_trend.update_xaxes(tickangle=45)
        fig_trend.update_layout(height=450, legend_title_text=entity_label)
        st.plotly_chart(fig_trend, width="stretch", key=f"{key}_trend")
        if len(entities) > MAX_LINES:
            st.caption(f"거래금액(절대값) 합계 상위 {MAX_LINES}개 {entity_label}만 표시합니다 (전체 {len(entities)}개).")
    else:
        st.info("선택한 조건에 해당하는 데이터가 없습니다.")

    st.subheader("AI 코멘트")
    comments = aic.generate_comments(fdf, entity_col=entity_col, account_col="계정명", entity_label=entity_label)
    if len(fdf):
        comments += aic.describe_causes(rca.summarize_causes(fdf))
    for c in comments:
        st.markdown(f"- {c}")

    st.subheader("불일치 상세")
    detail_cols = [entity_col, "계정명", "YYYYMM"]
    rename_map = {}
    if local1_col:
        detail_cols += [local1_col, local1_ccy_col]
        rename_map[local1_col] = f"{amt1_label}_현지통화"
        rename_map[local1_ccy_col] = f"{amt1_label}_통화"
    detail_cols.append(amt1_col)
    rename_map[amt1_col] = f"{amt1_label}_KRW"
    if local2_col:
        detail_cols += [local2_col, local2_ccy_col]
        rename_map[local2_col] = f"{amt2_label}_현지통화"
        rename_map[local2_ccy_col] = f"{amt2_label}_통화"
    detail_cols.append(amt2_col)
    rename_map[amt2_col] = f"{amt2_label}_KRW"
    detail_cols += ["차이금액", "차이율", "구분", "추정원인"]

    detail = mism.sort_values("_abs", ascending=False)[detail_cols] if len(mism) else mism[detail_cols]
    detail = detail.rename(columns=rename_map)
    detail["YYYYMM"] = detail["YYYYMM"].map(yyyymm_label)
    st.dataframe(detail, width="stretch", height=400)


st.title("내부거래검증 대시보드")

tab1, tab2 = st.tabs(["본사 대사", "법인간 거래"])

with tab1:
    render_dashboard(
        load_hq_data(), key="hq", entity_col="법인명", entity_label="법인",
        amt1_col="해외법인_KRW", amt1_label="해외법인", amt2_col="본사_KRW", amt2_label="본사",
        local1_col="해외법인_현지통화", local1_ccy_col="현지통화코드",
    )

with tab2:
    render_dashboard(
        load_pair_data(), key="pair", entity_col="법인쌍명", entity_label="법인쌍",
        amt1_col="법인1_KRW", amt1_label="법인1", amt2_col="법인2_KRW", amt2_label="법인2",
        local1_col="법인1_현지통화", local1_ccy_col="법인1통화코드",
        local2_col="법인2_현지통화", local2_ccy_col="법인2통화코드",
    )
