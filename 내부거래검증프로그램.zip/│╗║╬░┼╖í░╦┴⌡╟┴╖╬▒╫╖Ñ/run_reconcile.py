# -*- coding: utf-8 -*-
"""Phase 1 매칭/집계 엔진 실행 스크립트."""

import os
from src import reconcile as rc
from src import io_xlwings as xio

REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reports")


def main():
    os.makedirs(REPORTS_DIR, exist_ok=True)

    result = rc.run()

    print("=== 대사 결과 요약 ===")
    for k, v in rc.summarize(result).items():
        print(f"{k}: {v}")

    out_path = os.path.join(REPORTS_DIR, "phase1_reconcile_result.xlsx")
    with xio.excel_app() as app:
        xio.write_df_sheet(app, result, out_path, "reconcile_result")
    print(f"\n결과 파일 저장: {out_path}")


if __name__ == "__main__":
    main()
