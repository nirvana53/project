# -*- coding: utf-8 -*-
"""Phase 2 실행 스크립트 - 대사 결과를 법인/계정/월별 요약 + 불일치 상세 + 데이터 누락 상세
시트로 구성한 Excel 리포트를 생성한다."""

import os
import pandas as pd
from src import reconcile as rc
from src import report as rpt
from src import intercompany as ic
from src import ai_comment as aic
from src import root_cause as rca
from src import io_xlwings as xio

REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reports")


def comments_df(comments: list) -> pd.DataFrame:
    return pd.DataFrame({"AI 코멘트": comments})


def main():
    os.makedirs(REPORTS_DIR, exist_ok=True)

    result = rc.run()
    df = rpt.add_classification(result)
    df = rca.add_causes(df, entity_col="법인명", account_col="계정명", amt1_col="해외법인_KRW", amt2_col="본사_KRW")
    hq_cause_summary = rca.summarize_causes(df)
    hq_comments = aic.generate_comments(df, entity_col="법인명", account_col="계정명", entity_label="법인")
    hq_comments += aic.describe_causes(hq_cause_summary)

    pair_result = ic.run()
    pair_df = ic.add_classification(pair_result)
    pair_df["법인쌍명"] = pair_df["법인1명"] + " - " + pair_df["법인2명"]
    pair_df = rca.add_causes(pair_df, entity_col="법인쌍명", account_col="계정명", amt1_col="법인1_KRW", amt2_col="법인2_KRW")
    pair_cause_summary = rca.summarize_causes(pair_df)
    pair_summary = pd.DataFrame(list(ic.summarize(pair_result).items()), columns=["항목", "값"])
    pair_detail = pair_df.drop(columns=["법인쌍명"]).copy()
    pair_detail["_abs"] = pair_detail["차이금액"].abs()
    pair_detail = pair_detail.sort_values("_abs", ascending=False).drop(columns=["_abs"]).reset_index(drop=True)
    pair_comments = aic.generate_comments(pair_df, entity_col="법인쌍명", account_col="계정명", entity_label="법인쌍")
    pair_comments += aic.describe_causes(pair_cause_summary)

    sheets = {
        "요약(본사대사)": rpt.build_summary(df),
        "AI 코멘트(본사대사)": comments_df(hq_comments),
        "원인후보 요약(본사대사)": hq_cause_summary,
        "법인별 요약(본사대사)": rpt.build_group_summary(df, ["CORP_CD", "법인명"]),
        "계정별 요약(본사대사)": rpt.build_group_summary(df, ["ACCT_CD", "계정명"]),
        "월별 요약(본사대사)": rpt.build_group_summary(df, ["YYYYMM"]),
        "불일치 상세(본사대사)": rpt.build_amount_diff_detail(df),
        "데이터 누락 상세(본사대사)": rpt.build_missing_detail(df),
        "전체 결과(본사대사)": df,
        "요약(법인간거래)": pair_summary,
        "AI 코멘트(법인간거래)": comments_df(pair_comments),
        "원인후보 요약(법인간거래)": pair_cause_summary,
        "전체 결과(법인간거래)": pair_detail,
    }

    print("=== Phase 2 리포트 시트별 건수 ===")
    for name, sdf in sheets.items():
        print(f"[{name}] {len(sdf)}행")

    out_path = os.path.join(REPORTS_DIR, "reconcile_report.xlsx")
    with xio.excel_app() as app:
        xio.write_df_sheets(app, sheets, out_path)
    print(f"\n리포트 저장: {out_path}")


if __name__ == "__main__":
    main()
