# -*- coding: utf-8 -*-
"""
해외법인 담당자 앞 불일치 확인 메일 초안을 Outlook에 생성한다.

사전 준비
  1) config/corp_contacts.csv 의 EMAIL 컬럼을 법인별 실제 담당자 이메일로 채워 넣는다.
  2) Outlook이 정상적으로 켜져 있는 상태인지 확인한다 (Outlook.Application을 COM으로 구동함).

실행하면 법인별 불일치 내역을 담은 메일을 만들어 Outlook 임시보관함(초안)에만 저장한다.
실제 발송(.Send())은 절대 하지 않으므로, Outlook에서 내용을 검토한 뒤 사람이 직접 보내야 한다.

※ Outlook 연동 부분은 아직 실제로 테스트되지 않았다 (README/PROGRESS.txt 참고).
"""

from src import reconcile as rc
from src import report as rpt
from src import root_cause as rca
from src import mail


def main():
    result = rc.run()
    df = rpt.add_classification(result)
    df = rca.add_causes(df, entity_col="법인명", account_col="계정명",
                         amt1_col="해외법인_KRW", amt2_col="본사_KRW")

    contacts = mail.load_contacts()
    preview = mail.build_all_drafts_content(df, contacts)

    ready = [d for d in preview if d.get("email")]
    not_ready = [d for d in preview if not d.get("email")]

    print(f"=== 메일 생성 대상 법인: {len(preview)}개 (불일치 건이 있는 법인 기준) ===")
    for d in ready:
        print(f"  [준비됨] {d['corp_name']} ({d['corp_cd']}) - 불일치 {d['n_rows']}건 -> {d['email']}")
    for d in not_ready:
        print(f"  [건너뜀] {d['corp_name']} ({d['corp_cd']}) - 불일치 {d['n_rows']}건 - {d['skipped_reason']}")

    if not ready:
        print("\n이메일 주소가 설정된 법인이 없어 초안을 만들지 않았습니다.")
        print("config/corp_contacts.csv 의 EMAIL 컬럼을 채운 뒤 다시 실행해 주세요.")
        return

    answer = input(f"\n위 {len(ready)}개 법인 앞으로 Outlook 초안(임시보관함)을 생성할까요? (y/N): ").strip().lower()
    if answer != "y":
        print("취소되었습니다.")
        return

    summary = mail.generate_drafts_for_all(df, contacts)
    print(f"\n초안 생성 완료: {len(summary['created'])}건")
    for name, reason in summary["skipped"]:
        print(f"  건너뜀: {name} ({reason})")


if __name__ == "__main__":
    main()
