# -*- coding: utf-8 -*-
"""
Phase 3 (1차) - 규칙 기반 자동 코멘트 생성.

Anthropic API 키 없이도 바로 쓸 수 있도록, 대사 결과표(reconcile.py/intercompany.py가
'구분' 컬럼을 부여한 결과)에서 통계적으로 눈에 띄는 패턴을 규칙으로 탐지해 자연어
문장으로 요약한다.

나중에 API 키가 준비되면 find_* 함수들이 뽑아낸 '사실(fact)'을 프롬프트에 그대로 넣어
Anthropic API가 문장을 다듬거나 원인을 추론하게 하는 방식으로 확장할 수 있도록,
"사실 탐지"(find_*)와 "문장화"(generate_comments)를 의도적으로 분리해 두었다.
"""

from __future__ import annotations
import pandas as pd


def _fmt_krw(v: float) -> str:
    return f"{v:,.0f}원"


def _fmt_pct(v: float) -> str:
    return f"{v:.1%}"


def find_concentration(df: pd.DataFrame, entity_col: str, threshold: float = 0.2, max_items: int = 5) -> list[dict]:
    """불일치 금액이 특정 entity(법인/법인쌍)에 threshold 비중 이상 집중되어 있는지 탐지."""
    mism = df[df["구분"] != "일치"]
    total_abs = mism["차이금액"].abs().sum()
    if total_abs == 0:
        return []
    by_entity = mism.groupby(entity_col)["차이금액"].apply(lambda s: s.abs().sum()).sort_values(ascending=False)
    return [
        {"entity": entity, "amount": amt, "share": amt / total_abs}
        for entity, amt in by_entity.items() if amt / total_abs >= threshold
    ][:max_items]


def find_persistent_issues(
    df: pd.DataFrame, entity_col: str, account_col: str, z_threshold: float = 2.0, max_items: int = 5
) -> list[dict]:
    """같은 (entity, 계정) 조합의 불일치 개월수가 전체 평균보다 통계적으로 뚜렷하게 많은
    경우만 탐지한다 (절대 개월수 기준이 아니라 평균+표준편차 기준의 이상치 탐지).

    무작위성이 섞인 데이터에서는 "3개월 이상"처럼 낮은 절대 기준을 쓰면 우연히 발생하는
    평균적인 조합까지 전부 걸려 코멘트가 폭증하므로, 전체 분포 대비 유의하게 튀는 조합만
    상위 max_items개로 제한해 뽑는다.
    """
    mism = df[df["구분"] != "일치"]
    grp = mism.groupby([entity_col, account_col])["YYYYMM"].nunique()
    if len(grp) < 5:
        return []
    mean, std = grp.mean(), grp.std()
    if not std or pd.isna(std):
        return []
    z = (grp - mean) / std
    flagged = grp[z >= z_threshold].sort_values(ascending=False).head(max_items)
    return [{"entity": entity, "account": acct, "months": int(n)} for (entity, acct), n in flagged.items()]


def find_trend(df: pd.DataFrame, recent_n: int = 3) -> dict | None:
    """최근 N개월 불일치 금액 합계를 그 이전 평균과 비교해 추세를 탐지."""
    monthly = df[df["구분"] != "일치"].groupby("YYYYMM")["차이금액"].apply(lambda s: s.abs().sum())
    months = sorted(monthly.index)
    if len(months) < recent_n + 1:
        return None
    recent_avg = monthly.loc[months[-recent_n:]].mean()
    baseline_avg = monthly.loc[months[:-recent_n]].mean()
    if baseline_avg == 0:
        return None
    return {
        "recent_avg": recent_avg,
        "baseline_avg": baseline_avg,
        "change": (recent_avg - baseline_avg) / baseline_avg,
    }


def find_missing_concentration(
    df: pd.DataFrame, entity_col: str, threshold: float = 0.3, max_items: int = 5
) -> list[dict]:
    """'한쪽 데이터만 존재' 사례가 특정 entity에 threshold 비중 이상 몰려있는지 탐지."""
    missing = df[df["구분"].str.contains("만 존재")]
    if len(missing) == 0:
        return []
    total = len(missing)
    by_entity = missing.groupby(entity_col).size().sort_values(ascending=False)
    return [
        {"entity": entity, "count": int(cnt), "share": cnt / total}
        for entity, cnt in by_entity.items() if cnt / total >= threshold
    ][:max_items]


def generate_comments(df: pd.DataFrame, entity_col: str, account_col: str, entity_label: str = "법인") -> list[str]:
    """위 규칙들을 종합해 자연어 코멘트 리스트를 만든다."""
    comments = []

    total = len(df)
    mismatched = int((df["구분"] != "일치").sum())
    if total:
        comments.append(
            f"전체 {total:,}개 조합 중 {mismatched:,}건({_fmt_pct(mismatched / total)})이 불일치로 나타났습니다."
        )

    for f in find_concentration(df, entity_col):
        comments.append(
            f"{f['entity']}에 불일치 금액이 집중되어 있습니다 "
            f"(전체 불일치 금액의 {_fmt_pct(f['share'])}, {_fmt_krw(f['amount'])})."
        )

    for f in find_persistent_issues(df, entity_col, account_col):
        comments.append(
            f"{f['entity']}의 '{f['account']}' 계정은 총 {f['months']}개월에 걸쳐 반복적으로 불일치가 "
            f"발생했습니다 - 일회성 오류보다는 계정 매핑/환율 처리방식 등 구조적 원인 점검이 필요합니다."
        )

    trend = find_trend(df)
    if trend and abs(trend["change"]) >= 0.2:
        direction = "증가" if trend["change"] > 0 else "감소"
        comments.append(
            f"최근 불일치 금액이 이전 대비 {_fmt_pct(abs(trend['change']))} {direction}했습니다 "
            f"(최근 평균 {_fmt_krw(trend['recent_avg'])} vs 이전 평균 {_fmt_krw(trend['baseline_avg'])})."
        )

    for f in find_missing_concentration(df, entity_col):
        comments.append(
            f"'한쪽 데이터만 존재' 사례의 {_fmt_pct(f['share'])}({f['count']}건)가 {f['entity']}에서 "
            f"발생했습니다 - 해당 {entity_label}의 보고 프로세스를 우선 점검해보는 것을 권장합니다."
        )

    if len(comments) == 1:
        comments.append("특이사항 없이 대사 결과가 대체로 안정적입니다.")

    return comments


def describe_causes(cause_summary: pd.DataFrame, top_n: int = 3) -> list[str]:
    """root_cause.summarize_causes() 결과를 문장으로 요약한다 (Phase3 1차/2차 연결용)."""
    if cause_summary.empty:
        return []
    total = int(cause_summary["건수"].sum())
    top = cause_summary.head(top_n)
    parts = [f"{r['추정원인']} {int(r['건수'])}건({int(r['건수']) / total:.1%})" for _, r in top.iterrows()]
    return ["불일치 원인 후보를 분석한 결과, " + ", ".join(parts) + " 순으로 많았습니다."]
