# -*- coding: utf-8 -*-
"""
해외법인 간(법인간) 내부거래 교차검증.

GRPCRP_dummy 안에는 본사와의 거래 외에 서로 다른 두 해외법인 간의 거래(TCORP_CD가
본사가 아닌 다른 법인코드)도 섞여 있다. 이 거래는 SEP(본사)측에는 애초에 나타나지
않으므로 reconcile.py의 본사 대사 로직에서는 제외한다(build_sub_aggregate가
TCORP_CD=HQ인 행만 사용). 대신 이 모듈에서 GRPCRP 데이터끼리, A법인이 기표한
"B와의 거래"와 B법인이 기표한 "A와의 거래"를 (법인쌍, 계정, 연월) 단위로 서로 대사한다.
"""

import pandas as pd

from . import masters as m
from . import reconcile as rc


def build_pair_aggregate(grpcrp: pd.DataFrame, fx: pd.DataFrame) -> pd.DataFrame:
    """법인간 거래(TCORP_CD != HQ)를 (CORP_CD, TCORP_CD, ACCT_CD, YYYYMM) 단위로 KRW 집계."""
    df = grpcrp[grpcrp["TCORP_CD"] != m.HQ_CORP_CD].copy()
    df["ACCT_CD"] = df["ACCT_CD"].astype(str)
    df["CATEGORY"] = df["ACCT_CD"].map(m.classify_account)
    df["YYYYMM"] = df["SETTL_YM"].astype(int)
    df["TRAN_AMT"] = df["TRAN_AMT"].astype(float)

    rates = rc.rate_lookup(fx)

    def to_krw(row):
        rate_set = rates.get((row["YYYYMM"], str(row["CRNC_CD"])))
        if rate_set is None:
            raise KeyError(f"FX rate not found for {row['YYYYMM']} / {row['CRNC_CD']}")
        return float(row["TRAN_AMT"]) * float(rate_set[row["CATEGORY"]])

    df["KRW_AMT"] = df.apply(to_krw, axis=1)

    return df.groupby(["CORP_CD", "TCORP_CD", "ACCT_CD", "YYYYMM"], as_index=False).agg(
        KRW_AMT=("KRW_AMT", "sum"),
        현지통화=("TRAN_AMT", "sum"),
    )


def reconcile_pairs(agg: pd.DataFrame) -> pd.DataFrame:
    """A법인 기록 vs B법인 기록을 서로 대사한다. 같은 법인쌍은 한 행으로만 나타낸다."""
    left = agg.rename(columns={"KRW_AMT": "법인1_KRW", "현지통화": "법인1_현지통화"})
    right = agg.rename(columns={"CORP_CD": "TCORP_CD", "TCORP_CD": "CORP_CD",
                                 "KRW_AMT": "법인2_KRW", "현지통화": "법인2_현지통화"})

    merged = pd.merge(left, right, on=["CORP_CD", "TCORP_CD", "ACCT_CD", "YYYYMM"], how="outer")
    merged["법인1_KRW"] = merged["법인1_KRW"].fillna(0)
    merged["법인2_KRW"] = merged["법인2_KRW"].fillna(0)
    merged["법인1_현지통화"] = merged["법인1_현지통화"].fillna(0)
    merged["법인2_현지통화"] = merged["법인2_현지통화"].fillna(0)

    # outer 병합 결과에는 같은 법인쌍이 (A,B)/(B,A) 두 번 나타나므로, 코드 오름차순 기준으로
    # 한 번만 남긴다 (둘 중 정확히 하나만 CORP_CD < TCORP_CD 를 만족함).
    merged = merged[merged["CORP_CD"] < merged["TCORP_CD"]].copy()
    merged = merged.rename(columns={"CORP_CD": "법인1코드", "TCORP_CD": "법인2코드"})
    merged["법인1통화코드"] = merged["법인1코드"].map(m.CORP_CD_TO_CURRENCY)
    merged["법인2통화코드"] = merged["법인2코드"].map(m.CORP_CD_TO_CURRENCY)

    merged["차이금액"] = merged["법인1_KRW"] - merged["법인2_KRW"]
    base = merged[["법인1_KRW", "법인2_KRW"]].abs().max(axis=1)
    merged["차이율"] = merged.apply(
        lambda r: 0.0 if base.loc[r.name] == 0 else abs(r["차이금액"]) / base.loc[r.name], axis=1
    )

    def flag(row):
        if abs(row["차이금액"]) < rc.AMOUNT_THRESHOLD_KRW:
            return "N"
        if row["차이율"] > rc.RATIO_THRESHOLD:
            return "Y"
        return "N"

    merged["불일치여부"] = merged.apply(flag, axis=1)
    merged["법인1명"] = merged["법인1코드"].map(m.CORP_CD_TO_NAME)
    merged["법인2명"] = merged["법인2코드"].map(m.CORP_CD_TO_NAME)
    merged["계정명"] = merged["ACCT_CD"].map(m.account_name)

    cols = ["법인1코드", "법인1명", "법인2코드", "법인2명", "ACCT_CD", "계정명", "YYYYMM",
            "법인1_현지통화", "법인1통화코드", "법인2_현지통화", "법인2통화코드",
            "법인1_KRW", "법인2_KRW", "차이금액", "차이율", "불일치여부"]
    return merged[cols].sort_values(["법인1코드", "법인2코드", "ACCT_CD", "YYYYMM"]).reset_index(drop=True)


def classify_gap(row) -> str:
    if row["법인1_KRW"] == 0 and row["법인2_KRW"] != 0:
        return "법인2측만 존재"
    if row["법인2_KRW"] == 0 and row["법인1_KRW"] != 0:
        return "법인1측만 존재"
    if row["불일치여부"] == "Y":
        return "금액 불일치"
    return "일치"


def add_classification(result: pd.DataFrame) -> pd.DataFrame:
    df = result.copy()
    df["구분"] = df.apply(classify_gap, axis=1)
    return df


def summarize(result: pd.DataFrame) -> dict:
    total = len(result)
    mismatched = int((result["불일치여부"] == "Y").sum())
    return {
        "총 조합 건수(법인쌍x계정x연월)": total,
        "일치 건수": total - mismatched,
        "불일치 건수": mismatched,
        "불일치율": f"{mismatched / total:.1%}" if total else "0.0%",
        "법인1측만 존재": int(((result["법인2_KRW"] == 0) & (result["법인1_KRW"] != 0)).sum()),
        "법인2측만 존재": int(((result["법인1_KRW"] == 0) & (result["법인2_KRW"] != 0)).sum()),
        "차이금액 절대값 합계(KRW)": round(result["차이금액"].abs().sum()),
    }


def run() -> pd.DataFrame:
    grpcrp, _, fx = rc.load_raw()
    agg = build_pair_aggregate(grpcrp, fx)
    return reconcile_pairs(agg)


if __name__ == "__main__":
    result = run()
    for k, v in summarize(result).items():
        print(f"{k}: {v}")
