# -*- coding: utf-8 -*-
"""xlwings(Excel COM) 기반 xlsx 입출력 헬퍼. 프로젝트 규칙상 xlsx 열람은 xlwings로 통일한다."""

import contextlib
import pandas as pd
import xlwings as xw


@contextlib.contextmanager
def excel_app():
    app = xw.App(visible=False)
    try:
        yield app
    finally:
        app.quit()


def read_sheet_df(app, path: str, sheet_index: int = 0) -> pd.DataFrame:
    """xlsx 파일의 시트를 pandas DataFrame으로 읽는다 (헤더는 1행 기준)."""
    wb = app.books.open(path)
    try:
        sht = wb.sheets[sheet_index]
        data = sht.used_range.value
        header, rows = data[0], data[1:]
        return pd.DataFrame(rows, columns=header)
    finally:
        wb.close()


def _pre_format_text_columns(sht, df: pd.DataFrame) -> None:
    """문자열 컬럼은 숫자처럼 보여도 선행 0이 보존되도록 쓰기 전에 텍스트 서식을 지정한다.

    pandas 2.x는 문자열 컬럼 dtype이 object로 나오지만, pandas 3.x부터는 기본 문자열
    dtype이 별도의 str/StringDtype으로 바뀌었으므로 `dtype == object` 비교만으로는
    걸러지지 않는다. is_string_dtype으로 두 경우를 모두 잡는다.
    """
    nrows = len(df) + 1
    for ci, col in enumerate(df.columns, start=1):
        if pd.api.types.is_string_dtype(df[col]) or pd.api.types.is_object_dtype(df[col]):
            sht.range((2, ci), (max(nrows, 2), ci)).number_format = "@"


def write_df_sheet(app, df: pd.DataFrame, path: str, sheet_name: str) -> None:
    """DataFrame을 새 xlsx 파일 1개 시트로 저장한다."""
    wb = app.books.add()
    sht = wb.sheets[0]
    sht.name = sheet_name
    _pre_format_text_columns(sht, df)
    sht.range("A1").value = [list(df.columns)] + df.values.tolist()
    sht.autofit()
    wb.save(path)
    wb.close()


def write_df_sheets(app, sheet_map: dict, path: str) -> None:
    """{시트명: DataFrame} 딕셔너리를 여러 시트를 가진 xlsx 파일 1개로 저장한다."""
    wb = app.books.add()
    first = True
    for sheet_name, df in sheet_map.items():
        sht = wb.sheets[0] if first else wb.sheets.add(after=wb.sheets[-1])
        first = False
        sht.name = sheet_name
        _pre_format_text_columns(sht, df)
        sht.range("A1").value = [list(df.columns)] + df.values.tolist()
        sht.autofit()
    wb.save(path)
    wb.close()
