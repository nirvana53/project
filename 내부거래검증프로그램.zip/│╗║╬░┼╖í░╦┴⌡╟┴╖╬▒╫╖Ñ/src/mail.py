# -*- coding: utf-8 -*-
"""
해외법인 담당자 앞 불일치 확인 메일 초안 생성.

- 수신자는 config/corp_contacts.csv (CORP_CD, CORP_NAME, EMAIL)에서 읽는다. 더미 프로젝트라
  실제 이메일 주소가 없으므로 EMAIL 컬럼은 빈 값으로 두었고, 사용자가 직접 채워 넣어야 한다.
- 메일 본문은 한글 섹션 + 영어 섹션을 한 메일 안에 위아래로 붙인 bilingual 형식이다.
- Outlook COM(win32com.client)으로 메일 아이템을 만들고 반드시 .Save()만 호출해 임시보관함
  (초안)에만 남긴다. .Send()는 호출하지 않는다 - 실제 발송은 사람이 Outlook에서 검토 후
  직접 하도록 한다 (사용자와 합의된 방식).

※ Outlook 연동 부분(create_outlook_draft, generate_drafts_for_all)은 아직 실제 Outlook을
  띄워 테스트하지 않았다 - 이 PC에서 Outlook 최초 실행이 오래 걸려 사용자가 나중에 직접
  연결/테스트하기로 함. 본문 생성 로직(compose_subject, compose_body_html 등)만 우선 구현.
"""

import os
import pandas as pd

CONFIG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")
CONTACTS_PATH = os.path.join(CONFIG_DIR, "corp_contacts.csv")

# root_cause.py의 한글 원인 라벨 -> 영문 번역
CAUSE_EN = {
    "시점차이(귀속월) 추정": "Timing difference (period cut-off) suspected",
    "부호반전 의심": "Sign reversal suspected",
    "자릿수/배수 오류 의심": "Digit/multiple error suspected",
    "환율/반올림 차이 의심(경미)": "Minor FX rate / rounding difference suspected",
    "미기표 추정": "Entry likely missing on one side",
    "금액 불일치(원인불명)": "Amount mismatch (cause unknown)",
    "해당없음": "N/A",
}


def load_contacts() -> pd.DataFrame:
    return pd.read_csv(CONTACTS_PATH, dtype=str).fillna("")


def get_corp_mismatches(df: pd.DataFrame, corp_cd: str) -> pd.DataFrame:
    """본사 대사 결과(df, src.report.add_classification 결과)에서 특정 법인의 불일치 건만
    차이금액 절대값 내림차순으로 정렬해 반환한다."""
    sub = df[(df["CORP_CD"] == corp_cd) & (df["구분"] != "일치")].copy()
    sub["_abs"] = sub["차이금액"].abs()
    return sub.sort_values("_abs", ascending=False).drop(columns=["_abs"])


def _yyyymm_label(v) -> str:
    y, mo = divmod(int(v), 100)
    return f"{y}-{mo:02d}"


def _rows_html(rows: pd.DataFrame, lang: str) -> str:
    if lang == "kr":
        headers = ["계정", "연월", "해외법인 금액(KRW)", "본사 금액(KRW)", "차이금액(KRW)", "차이율", "추정 원인"]
    else:
        headers = ["Account", "Period", "Overseas Entity (KRW)", "HQ (KRW)", "Difference (KRW)", "Diff %", "Estimated Cause"]

    head_html = "".join(f"<th style='border:1px solid #ccc;padding:4px 8px;background:#f2f2f2'>{h}</th>" for h in headers)
    body_rows = []
    for _, r in rows.iterrows():
        cause = r["추정원인"] if lang == "kr" else CAUSE_EN.get(r["추정원인"], r["추정원인"])
        cells = [
            r["계정명"], _yyyymm_label(r["YYYYMM"]),
            f"{r['해외법인_KRW']:,.0f}", f"{r['본사_KRW']:,.0f}",
            f"{r['차이금액']:,.0f}", f"{r['차이율']:.1%}", cause,
        ]
        cells_html = "".join(f"<td style='border:1px solid #ccc;padding:4px 8px'>{c}</td>" for c in cells)
        body_rows.append(f"<tr>{cells_html}</tr>")

    return (
        "<table style='border-collapse:collapse;font-size:13px'>"
        f"<tr>{head_html}</tr>{''.join(body_rows)}</table>"
    )


def compose_subject(corp_name: str, rows: pd.DataFrame) -> str:
    period = f"{_yyyymm_label(rows['YYYYMM'].min())} ~ {_yyyymm_label(rows['YYYYMM'].max())}"
    return (
        f"[내부거래 대사] {corp_name} - {period} 불일치 확인 요청 / "
        f"[Intercompany Reconciliation] Discrepancy Review Request - {corp_name} ({period})"
    )


def compose_body_html(corp_name: str, rows: pd.DataFrame) -> str:
    kr = f"""
    <p>안녕하세요, {corp_name} 담당자님,</p>
    <p>본사-법인 간 내부거래 대사 결과, 아래와 같이 귀사와 본사 기록 간 불일치가 발견되어
    확인을 요청드립니다.</p>
    {_rows_html(rows, "kr")}
    <p>확인 후 회신 부탁드립니다. 감사합니다.</p>
    """
    en = f"""
    <p>Dear {corp_name} team,</p>
    <p>Based on the latest intercompany reconciliation between Headquarters and your entity,
    the following discrepancies were identified. Please review and let us know your findings.</p>
    {_rows_html(rows, "en")}
    <p>We would appreciate your confirmation at your earliest convenience. Thank you.</p>
    """
    return f"<div>{kr}<hr>{en}</div>"


def build_all_drafts_content(df: pd.DataFrame, contacts: pd.DataFrame) -> list[dict]:
    """법인별로 (수신자 이메일, 제목, 본문) 딕셔너리를 만든다. Outlook은 건드리지 않는다.
    이메일 주소가 비어 있거나 불일치 건이 없는 법인은 건너뛴다."""
    drafts = []
    for _, contact in contacts.iterrows():
        corp_cd, corp_name, email = contact["CORP_CD"], contact["CORP_NAME"], contact["EMAIL"].strip()
        rows = get_corp_mismatches(df, corp_cd)
        if len(rows) == 0:
            continue
        if not email:
            drafts.append({"corp_cd": corp_cd, "corp_name": corp_name, "email": None,
                            "n_rows": len(rows), "skipped_reason": "이메일 주소 미설정"})
            continue
        drafts.append({
            "corp_cd": corp_cd, "corp_name": corp_name, "email": email, "n_rows": len(rows),
            "subject": compose_subject(corp_name, rows), "body_html": compose_body_html(corp_name, rows),
        })
    return drafts


def create_outlook_draft(to_email: str, subject: str, body_html: str) -> None:
    """Outlook 메일 아이템을 만들어 임시보관함(초안)에만 저장한다 (.Send() 호출하지 않음).

    ※ 아직 실제 Outlook으로 테스트하지 않은 함수. 이 PC에서 Outlook 최초 실행이 오래 걸려
    사용자가 준비되면 직접 연결/테스트하기로 함.
    """
    import win32com.client as win32

    outlook = win32.Dispatch("Outlook.Application")
    mail = outlook.CreateItem(0)  # olMailItem
    mail.To = to_email
    mail.Subject = subject
    mail.HTMLBody = body_html
    mail.Save()  # Drafts 폴더에 저장. Send()는 호출하지 않음.


def generate_drafts_for_all(df: pd.DataFrame, contacts: pd.DataFrame) -> dict:
    """법인별로 초안을 실제로 생성한다 (Outlook 필요). 요약 결과를 반환한다."""
    drafts = build_all_drafts_content(df, contacts)
    created, skipped = [], []
    for d in drafts:
        if d.get("email"):
            create_outlook_draft(d["email"], d["subject"], d["body_html"])
            created.append(d["corp_name"])
        else:
            skipped.append((d["corp_name"], d.get("skipped_reason", "알 수 없음")))
    return {"created": created, "skipped": skipped}
