# -*- coding: utf-8 -*-
"""법인/계정 마스터 데이터 - GRPCRP_dummy, SEP_dummy, FX_dummy 생성 시 사용한 값과 동일하게 유지."""

HQ_CORP_CD = "YC000"

CORP_MASTER = [
    {"CORP_CD": "YC001", "CORP_NAME": "HSTEEL Vietnam Co., Ltd.",   "BP_KEY": "0000A10001", "CURRENCY": "VND", "KUNNR": "0000100000", "LIFNR": "0000200000"},
    {"CORP_CD": "YC002", "CORP_NAME": "HSTEEL America Corp.",       "BP_KEY": "0000A10002", "CURRENCY": "USD", "KUNNR": "0000100111", "LIFNR": "0000200131"},
    {"CORP_CD": "YC003", "CORP_NAME": "HSTEEL Mexico S.A. de C.V.", "BP_KEY": "0000A10003", "CURRENCY": "MXN", "KUNNR": "0000100222", "LIFNR": "0000200262"},
    {"CORP_CD": "YC004", "CORP_NAME": "HSTEEL Investment",          "BP_KEY": "0000A10004", "CURRENCY": "HKD", "KUNNR": "0000100333", "LIFNR": "0000200393"},
    {"CORP_CD": "YC005", "CORP_NAME": "HSTEEL India Private Ltd.",  "BP_KEY": "0000A10005", "CURRENCY": "INR", "KUNNR": "0000100444", "LIFNR": "0000200524"},
    {"CORP_CD": "YC006", "CORP_NAME": "HSTEEL (Suzhou) Co., Ltd.",  "BP_KEY": "0000A10006", "CURRENCY": "CNY", "KUNNR": "0000100555", "LIFNR": "0000200655"},
    {"CORP_CD": "YC007", "CORP_NAME": "HSTEEL Indonesia PT",        "BP_KEY": "0000A10007", "CURRENCY": "IDR", "KUNNR": "0000100666", "LIFNR": "0000200786"},
    {"CORP_CD": "YC008", "CORP_NAME": "HSTEEL Poland Sp. z o.o.",   "BP_KEY": "0000A10008", "CURRENCY": "PLN", "KUNNR": "0000100777", "LIFNR": "0000200917"},
    {"CORP_CD": "YC009", "CORP_NAME": "HSTEEL Germany GmbH",        "BP_KEY": "0000A10009", "CURRENCY": "EUR", "KUNNR": "0000100888", "LIFNR": "0000201048"},
    {"CORP_CD": "YC010", "CORP_NAME": "HSTEEL Japan K.K.",          "BP_KEY": "0000A10010", "CURRENCY": "JPY", "KUNNR": "0000100999", "LIFNR": "0000201179"},
    {"CORP_CD": "YC011", "CORP_NAME": "HSTEEL Thailand Co., Ltd.",  "BP_KEY": "0000A10011", "CURRENCY": "THB", "KUNNR": "0000101110", "LIFNR": "0000201310"},
    {"CORP_CD": "YC012", "CORP_NAME": "HSTEEL Brazil Ltda.",        "BP_KEY": "0000A10012", "CURRENCY": "BRL", "KUNNR": "0000101221", "LIFNR": "0000201441"},
    {"CORP_CD": "YC013", "CORP_NAME": "HSTEEL Turkey A.S.",         "BP_KEY": "0000A10013", "CURRENCY": "TRY", "KUNNR": "0000101332", "LIFNR": "0000201572"},
    {"CORP_CD": "YC014", "CORP_NAME": "HSTEEL UK Ltd.",             "BP_KEY": "0000A10014", "CURRENCY": "GBP", "KUNNR": "0000101443", "LIFNR": "0000201703"},
    {"CORP_CD": "YC015", "CORP_NAME": "HSTEEL Singapore Pte. Ltd.", "BP_KEY": "0000A10015", "CURRENCY": "SGD", "KUNNR": "0000101554", "LIFNR": "0000201834"},
]

HQ_CORP_NAME = "HSTEEL Co., Ltd. (HQ)"

BP_KEY_TO_CORP_CD = {c["BP_KEY"]: c["CORP_CD"] for c in CORP_MASTER}
CORP_CD_TO_CURRENCY = {c["CORP_CD"]: c["CURRENCY"] for c in CORP_MASTER}
CORP_CD_TO_NAME = {c["CORP_CD"]: c["CORP_NAME"] for c in CORP_MASTER}
CORP_CD_TO_NAME[HQ_CORP_CD] = HQ_CORP_NAME

# sign: 정상잔액 방향의 부호 (수취/수익=+1, 지급/비용=-1). KUNNR/LIFNR 사용 여부와 금액 부호에 사용.
ACCOUNT_MASTER = {
    "0011010101": {"name": "Intercompany AR",                 "category": "BS", "sign": 1},
    "0011010102": {"name": "Intercompany Accrued Income",     "category": "BS", "sign": 1},
    "0012010101": {"name": "Intercompany Loans Receivable",   "category": "BS", "sign": 1},
    "0021010101": {"name": "Intercompany AP",                 "category": "BS", "sign": -1},
    "0021010102": {"name": "Intercompany Accrued Expense",    "category": "BS", "sign": -1},
    "0022010101": {"name": "Intercompany Borrowings",         "category": "BS", "sign": -1},
    "0031010101": {"name": "Intercompany Advances Received",  "category": "BS", "sign": -1},
    "0041010101": {"name": "Intercompany Product Sales",      "category": "PL", "sign": 1},
    "0042010101": {"name": "Intercompany Service Revenue",    "category": "PL", "sign": 1},
    "0051010101": {"name": "Intercompany COGS",               "category": "PL", "sign": -1},
    "0061010101": {"name": "Intercompany Interest Income",    "category": "PL", "sign": 1},
    "0071010101": {"name": "Intercompany Interest Expense",   "category": "PL", "sign": -1},
    "0081010101": {"name": "Intercompany Fee Expense",        "category": "PL", "sign": -1},
    "0082010101": {"name": "Intercompany Commission Paid",    "category": "PL", "sign": -1},
}


def classify_account(acct_cd: str) -> str:
    """GL계정 앞자리 규칙: 1,2,3=자산/부채(BS), 4~8=수익/비용(PL)."""
    digits = str(acct_cd).lstrip("0")
    if not digits:
        raise ValueError(f"invalid account code: {acct_cd}")
    d0 = digits[0]
    if d0 in "123":
        return "BS"
    if d0 in "45678":
        return "PL"
    raise ValueError(f"account code does not follow 1-8 leading digit rule: {acct_cd}")


def account_name(acct_cd: str) -> str:
    meta = ACCOUNT_MASTER.get(str(acct_cd))
    return meta["name"] if meta else "(미등록 계정)"
