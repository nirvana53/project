# -*- coding: utf-8 -*-
"""
Phase 1 - 법인 x 계정 x 월 단위 내부거래 대사(매칭/집계) 엔진.

흐름:
  1) GRPCRP_dummy(해외법인), SEP_dummy(본사), FX_dummy(환율)를 xlwings로 로드
  2) 계정 성격(BS/PL)에 따라 기말환율/누계평균환율을 적용해 KRW로 환산
  3) (법인코드, GL계정, 연월) 단위로 양쪽을 집계
  4) 두 집계를 outer join 하여 차이금액/차이율을 계산하고 임계값 기준으로 불일치 플래그
"""

import os
import datetime
import pandas as pd

from . import masters as m
from . import io_xlwings as xio

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
GRPCRP_PATH = os.path.join(DATA_DIR, "GRPCRP_dummy.xlsx")
SEP_PATH = os.path.join(DATA_DIR, "SEP_dummy.xlsx")
FX_PATH = os.path.join(DATA_DIR, "FX_dummy.xlsx")

# 불일치 판정 임계값 (PROGRESS.txt Phase1 "미정 사항" - 잠정 기본값, 추후 확정 필요)
AMOUNT_THRESHOLD_KRW = 1_000_000       # 차이금액이 이 값 미만이면 임계값상 무시
RATIO_THRESHOLD = 0.05                 # 차이율(차이금액/기준금액)이 이 값을 넘으면 불일치


def _excel_serial_to_yyyymm(serial) -> int:
    d = datetime.date(1899, 12, 30) + datetime.timedelta(days=int(serial))
    return d.year * 100 + d.month


def load_raw() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    with xio.excel_app() as app:
        grpcrp = xio.read_sheet_df(app, GRPCRP_PATH)
        sep = xio.read_sheet_df(app, SEP_PATH)
        fx = xio.read_sheet_df(app, FX_PATH)
    return grpcrp, sep, fx


def rate_lookup(fx: pd.DataFrame) -> dict:
    """(연월, 통화코드) -> {'BS': 기말환율, 'PL': 누계평균환율}"""
    lut = {}
    for _, r in fx.iterrows():
        key = (int(r["연월"]), str(r["통화코드"]))
        lut[key] = {"BS": r["기말환율(KRW)"], "PL": r["누계평균환율(KRW)"]}
    return lut


def build_sub_aggregate(grpcrp: pd.DataFrame, fx: pd.DataFrame) -> pd.DataFrame:
    """해외법인(GRPCRP) 데이터 중 본사(TCORP_CD=YC000)와의 거래만 법인x계정x연월 단위로 KRW 집계.

    GRPCRP_dummy에는 본사와의 거래뿐 아니라 다른 해외법인과의 거래("법인간 거래")도 섞여
    있는데, SEP(본사)측은 그런 거래를 애초에 알 수 없으므로 여기서 제외하지 않으면 본사와
    무관한 금액이 섞여 대사 결과가 왜곡된다. 법인간 거래 자체의 교차검증은
    src/intercompany.py에서 GRPCRP 데이터끼리만으로 별도 수행한다.
    """
    df = grpcrp[grpcrp["TCORP_CD"] == m.HQ_CORP_CD].copy()
    df["ACCT_CD"] = df["ACCT_CD"].astype(str)
    df["CATEGORY"] = df["ACCT_CD"].map(m.classify_account)
    df["YYYYMM"] = df["SETTL_YM"].astype(int)
    df["TRAN_AMT"] = df["TRAN_AMT"].astype(float)

    rates = rate_lookup(fx)

    def to_krw(row):
        rate_set = rates.get((row["YYYYMM"], str(row["CRNC_CD"])))
        if rate_set is None:
            raise KeyError(f"FX rate not found for {row['YYYYMM']} / {row['CRNC_CD']}")
        rate = rate_set[row["CATEGORY"]]
        return float(row["TRAN_AMT"]) * float(rate)

    df["KRW_AMT"] = df.apply(to_krw, axis=1)

    agg = df.groupby(["CORP_CD", "ACCT_CD", "YYYYMM"], as_index=False).agg(
        해외법인_KRW=("KRW_AMT", "sum"),
        해외법인_현지통화=("TRAN_AMT", "sum"),
    )
    return agg


def build_hq_aggregate(sep: pd.DataFrame, fx: pd.DataFrame) -> pd.DataFrame:
    """본사(SEP) 데이터를 법인x계정x연월 단위로 KRW 집계."""
    df = sep.copy()
    df["GL계정"] = df["GL계정"].astype(str)
    df["CATEGORY"] = df["GL계정"].map(m.classify_account)
    df["YYYYMM"] = df["전기일"].map(_excel_serial_to_yyyymm)
    df["CORP_CD"] = df["BP_Key"].map(m.BP_KEY_TO_CORP_CD)

    unmapped = df[df["CORP_CD"].isna()]
    if len(unmapped):
        raise KeyError(f"BP_Key 매핑 실패 {len(unmapped)}건: {unmapped['BP_Key'].unique()[:5]}")

    rates = rate_lookup(fx)

    def to_krw(row):
        rate_set = rates.get((row["YYYYMM"], str(row["전표통화키"])))
        if rate_set is None:
            raise KeyError(f"FX rate not found for {row['YYYYMM']} / {row['전표통화키']}")
        rate = rate_set[row["CATEGORY"]]
        return float(row["[전표통화금액]"]) * float(rate)

    df["KRW_AMT"] = df.apply(to_krw, axis=1)

    agg = (
        df.groupby(["CORP_CD", "GL계정", "YYYYMM"], as_index=False)["KRW_AMT"]
        .sum()
        .rename(columns={"GL계정": "ACCT_CD", "KRW_AMT": "본사_KRW"})
    )
    return agg


def reconcile(sub_agg: pd.DataFrame, hq_agg: pd.DataFrame) -> pd.DataFrame:
    """법인x계정x연월 단위로 두 집계를 대사하여 차이/불일치 여부를 계산."""
    merged = pd.merge(sub_agg, hq_agg, on=["CORP_CD", "ACCT_CD", "YYYYMM"], how="outer")
    merged["해외법인_KRW"] = merged["해외법인_KRW"].fillna(0)
    merged["본사_KRW"] = merged["본사_KRW"].fillna(0)
    merged["해외법인_현지통화"] = merged["해외법인_현지통화"].fillna(0)
    # 해외법인측 데이터가 아예 없는 행(본사측만 존재)도 그 법인이 원래 쓰는 통화가 무엇인지는
    # 알 수 있으므로, 실제 거래 유무와 무관하게 법인 마스터에서 통화코드를 붙여준다.
    merged["현지통화코드"] = merged["CORP_CD"].map(m.CORP_CD_TO_CURRENCY)

    # 부호 규칙: 두 원장이 동일 계정코드를 각자 관점에서 독립적으로 기표하므로,
    # 대사 시에는 "두 금액의 절대값 차이"를 기준으로 판단한다 (부호 상호 대응은 Phase1 범위 밖).
    merged["차이금액"] = merged["해외법인_KRW"] - merged["본사_KRW"]
    base = merged[["해외법인_KRW", "본사_KRW"]].abs().max(axis=1)
    merged["차이율"] = merged.apply(
        lambda r: 0.0 if base.loc[r.name] == 0 else abs(r["차이금액"]) / base.loc[r.name], axis=1
    )

    def flag(row):
        if abs(row["차이금액"]) < AMOUNT_THRESHOLD_KRW:
            return "N"
        if row["차이율"] > RATIO_THRESHOLD:
            return "Y"
        return "N"

    merged["불일치여부"] = merged.apply(flag, axis=1)
    merged["계정명"] = merged["ACCT_CD"].map(m.account_name)
    merged["법인명"] = merged["CORP_CD"].map(
        {c["CORP_CD"]: c["CORP_NAME"] for c in m.CORP_MASTER}
    )

    cols = ["CORP_CD", "법인명", "ACCT_CD", "계정명", "YYYYMM",
            "해외법인_현지통화", "현지통화코드", "해외법인_KRW", "본사_KRW",
            "차이금액", "차이율", "불일치여부"]
    merged = merged[cols].sort_values(["CORP_CD", "ACCT_CD", "YYYYMM"]).reset_index(drop=True)
    return merged


def summarize(result: pd.DataFrame) -> dict:
    total = len(result)
    mismatched = int((result["불일치여부"] == "Y").sum())
    return {
        "총 조합 건수(법인x계정x연월)": total,
        "불일치 건수": mismatched,
        "불일치율": f"{mismatched / total:.1%}" if total else "0.0%",
        "해외법인측만 존재": int(((result["본사_KRW"] == 0) & (result["해외법인_KRW"] != 0)).sum()),
        "본사측만 존재": int(((result["해외법인_KRW"] == 0) & (result["본사_KRW"] != 0)).sum()),
        "차이금액 합계(KRW)": round(result["차이금액"].sum()),
        "차이금액 절대값 합계(KRW)": round(result["차이금액"].abs().sum()),
    }


def run() -> pd.DataFrame:
    grpcrp, sep, fx = load_raw()
    sub_agg = build_sub_aggregate(grpcrp, fx)
    hq_agg = build_hq_aggregate(sep, fx)
    result = reconcile(sub_agg, hq_agg)
    return result


if __name__ == "__main__":
    result = run()
    for k, v in summarize(result).items():
        print(f"{k}: {v}")
