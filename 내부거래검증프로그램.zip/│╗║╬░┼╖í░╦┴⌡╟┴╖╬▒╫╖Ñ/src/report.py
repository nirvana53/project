# -*- coding: utf-8 -*-
"""
Phase 2 - 대사 결과(reconcile.run())를 법인/계정/월별 요약과 불일치 상세로 정리한다.

Phase 1의 결과표(법인x계정x연월 단위)에 '구분' 컬럼을 추가해 아래 네 가지로 분류한다.
  - 일치            : 불일치여부 = N
  - 금액 불일치      : 양쪽 다 데이터가 있으나 임계값을 초과해 불일치로 판정
  - 해외법인측만 존재 : 본사(SEP) 쪽에 대응 데이터가 없음
  - 본사측만 존재    : 해외법인(GRPCRP) 쪽에 대응 데이터가 없음
"""

import pandas as pd


def classify_gap(row) -> str:
    if row["해외법인_KRW"] == 0 and row["본사_KRW"] != 0:
        return "본사측만 존재"
    if row["본사_KRW"] == 0 and row["해외법인_KRW"] != 0:
        return "해외법인측만 존재"
    if row["불일치여부"] == "Y":
        return "금액 불일치"
    return "일치"


def add_classification(result: pd.DataFrame) -> pd.DataFrame:
    df = result.copy()
    df["구분"] = df.apply(classify_gap, axis=1)
    return df


def build_summary(df: pd.DataFrame) -> pd.DataFrame:
    total = len(df)
    mismatched = int((df["불일치여부"] == "Y").sum())
    rows = [
        ("총 조합 건수(법인x계정x연월)", total),
        ("일치 건수", int((df["구분"] == "일치").sum())),
        ("불일치 건수", mismatched),
        ("불일치율", f"{mismatched / total:.1%}" if total else "0.0%"),
        ("  - 금액 불일치", int((df["구분"] == "금액 불일치").sum())),
        ("  - 해외법인측만 존재", int((df["구분"] == "해외법인측만 존재").sum())),
        ("  - 본사측만 존재", int((df["구분"] == "본사측만 존재").sum())),
        ("차이금액 합계(KRW, 방향 포함)", round(df["차이금액"].sum())),
        ("차이금액 절대값 합계(KRW)", round(df["차이금액"].abs().sum())),
    ]
    return pd.DataFrame(rows, columns=["항목", "값"])


def build_group_summary(df: pd.DataFrame, group_cols: list) -> pd.DataFrame:
    g = df.groupby(group_cols, as_index=False).agg(
        총건수=("불일치여부", "size"),
        일치건수=("구분", lambda s: (s == "일치").sum()),
        금액불일치=("구분", lambda s: (s == "금액 불일치").sum()),
        해외법인측만존재=("구분", lambda s: (s == "해외법인측만 존재").sum()),
        본사측만존재=("구분", lambda s: (s == "본사측만 존재").sum()),
        차이금액절대값합계=("차이금액", lambda s: round(s.abs().sum())),
    )
    g["불일치율"] = ((g["총건수"] - g["일치건수"]) / g["총건수"]).map(lambda v: f"{v:.1%}")
    g = g.sort_values("차이금액절대값합계", ascending=False).reset_index(drop=True)
    return g


_DETAIL_COLS = ["구분", "CORP_CD", "법인명", "ACCT_CD", "계정명", "YYYYMM",
                "해외법인_현지통화", "현지통화코드", "해외법인_KRW", "본사_KRW",
                "차이금액", "차이율"]


def _sorted_detail(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["_abs"] = d["차이금액"].abs()
    d = d.sort_values("_abs", ascending=False).drop(columns=["_abs"])
    cols = _DETAIL_COLS + ["추정원인"] if "추정원인" in d.columns else _DETAIL_COLS
    return d[cols].reset_index(drop=True)


def build_amount_diff_detail(df: pd.DataFrame) -> pd.DataFrame:
    """양쪽 다 데이터가 있으나 금액이 임계값 이상 차이나는 건."""
    return _sorted_detail(df[df["구분"] == "금액 불일치"])


def build_missing_detail(df: pd.DataFrame) -> pd.DataFrame:
    """한쪽 데이터가 아예 없는(상대방 데이터 누락) 건."""
    return _sorted_detail(df[df["구분"].isin(["해외법인측만 존재", "본사측만 존재"])])
