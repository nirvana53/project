# -*- coding: utf-8 -*-
"""
Phase 3 (2차) - 불일치 원인 후보 자동 분류.

실제 원인은 알 수 없으므로(사람이 확인하기 전까지는), 대사 결과 데이터 자체에서
관찰 가능한 패턴만으로 "확인해볼 가설"을 제시하는 규칙 기반 분류기다. 확정적 진단이
아니라 담당자가 어디부터 확인하면 좋을지 우선순위를 좁혀주는 용도로 사용한다.

분류 규칙 (우선순위 순)
  1) 일치                        : 애초에 불일치가 아님
  2) 시점차이(귀속월) 추정        : 한쪽만 존재하는데, 인접월(전월/익월)에 없던 쪽 데이터가
                                    비슷한 금액으로 나타남 -> 기간 귀속(cut-off) 차이 가능성
  3) 부호반전 의심                : 양쪽 다 있는데 금액 부호가 반대이고 크기는 비슷함 ->
                                    차변/대변을 반대로 기표했을 가능성
  4) 자릿수/배수 오류 의심        : 두 금액의 비율이 10, 100, 1000배(또는 그 역수)에 가까움 ->
                                    통화 단위/자릿수 입력 실수 가능성
  5) 환율/반올림 차이 의심(경미)  : 양쪽 다 있고 차이율이 크지 않음(15% 이하) -> 환율 종류
                                    선택이나 반올림 차이일 가능성
  6) 미기표 추정                  : 한쪽만 존재하고 인접월에서도 설명이 안 됨 -> 아예 빠뜨렸을 가능성
  7) 금액 불일치(원인불명)        : 위 어느 것으로도 설명되지 않는 큰 금액 차이 -> 개별 확인 필요
"""

from __future__ import annotations
import pandas as pd

_ROUND_MULTIPLES = (10, 100, 1000)


def _shift_ym(yyyymm: int, shift: int) -> int:
    y, mo = divmod(yyyymm, 100)
    mo += shift
    while mo < 1:
        mo += 12
        y -= 1
    while mo > 12:
        mo -= 12
        y += 1
    return y * 100 + mo


def _is_near_round_multiple(ratio: float, tol: float = 0.05) -> bool:
    for k in _ROUND_MULTIPLES:
        if abs(ratio - k) / k < tol or abs(ratio - 1 / k) / (1 / k) < tol:
            return True
    return False


def estimate_causes(
    df: pd.DataFrame, entity_col: str, account_col: str, amt1_col: str, amt2_col: str,
    timing_tolerance: float = 0.05, minor_ratio_cutoff: float = 0.15,
) -> pd.Series:
    """행별로 원인 후보 라벨을 붙인 Series를 반환한다. df 자체는 변경하지 않는다."""
    lookup = {
        (row[entity_col], row[account_col], int(row["YYYYMM"])): row
        for _, row in df.iterrows()
    }

    def classify(row) -> str:
        if row["구분"] == "일치":
            return "해당없음"

        amt1, amt2 = row[amt1_col], row[amt2_col]

        if amt1 == 0 or amt2 == 0:
            missing_col, present_amt = (amt1_col, amt2) if amt1 == 0 else (amt2_col, amt1)
            entity, acct, ym = row[entity_col], row[account_col], int(row["YYYYMM"])
            for shift in (-1, 1):
                neighbor = lookup.get((entity, acct, _shift_ym(ym, shift)))
                if neighbor is None:
                    continue
                neighbor_amt = neighbor[missing_col]
                if neighbor_amt != 0 and present_amt != 0:
                    if abs(abs(neighbor_amt) - abs(present_amt)) / abs(present_amt) < timing_tolerance:
                        return "시점차이(귀속월) 추정"
            return "미기표 추정"

        # 양쪽 다 존재하는데 임계값을 넘어 불일치로 판정된 경우
        if abs(amt1 + amt2) / max(abs(amt1), abs(amt2)) < 0.05:
            return "부호반전 의심"

        ratio = abs(amt1) / abs(amt2) if amt2 != 0 else None
        if ratio is not None and _is_near_round_multiple(ratio):
            return "자릿수/배수 오류 의심"

        if row["차이율"] <= minor_ratio_cutoff:
            return "환율/반올림 차이 의심(경미)"

        return "금액 불일치(원인불명)"

    return df.apply(classify, axis=1)


def add_causes(df: pd.DataFrame, entity_col: str, account_col: str, amt1_col: str, amt2_col: str) -> pd.DataFrame:
    out = df.copy()
    out["추정원인"] = estimate_causes(out, entity_col, account_col, amt1_col, amt2_col)
    return out


def summarize_causes(df: pd.DataFrame) -> pd.DataFrame:
    counts = df["추정원인"].value_counts()
    counts = counts.drop(index="해당없음", errors="ignore")
    return counts.rename_axis("추정원인").reset_index(name="건수").sort_values("건수", ascending=False)
