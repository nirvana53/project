# -*- coding: utf-8 -*-
"""
GRPCRP_dummy.xlsx / SEP_dummy.xlsx 재생성 스크립트.

설계: 해외법인의 내부거래 중 "본사(HQ)와의 거래"는 실제로 서로 대응되는 짝 데이터로
생성하되, 아래 유형별로 의도적 불일치를 섞어 검증 프로그램이 실제로 일치/불일치를
가려낼 수 있는 테스트 데이터를 만든다.

  - MATCHED (80%)       : 금액/시점 모두 대응 (환산 후 근사 일치 -> 대사 결과 '불일치여부'=N)
  - MISSING_SEP (5%)    : 해외법인만 기표, 본사 미기표 ("해외법인측만 존재")
  - MISSING_GRPCRP (5%) : 본사만 기표, 해외법인 미기표 ("본사측만 존재")
  - AMOUNT_DIFF (5%)    : 양쪽 다 기표하지만 금액이 서로 다름
  - TIMING_DIFF (5%)    : 금액은 대응되지만 인식월이 ±1개월 차이 (기간 귀속차이)

해외법인이 본사가 아닌 다른 해외법인과 거래하는 "법인간 거래"도 동일한 방식(80% 대응,
20% 유형별 불일치)으로 짝을 지어 생성한다. 이 거래는 GRPCRP_dummy 안에서 A법인의
"B와의 거래" 행과 B법인의 "A와의 거래" 행으로 각각 남고, 본사 SEP 데이터에는 대응 내역이
존재하지 않는다 (본사가 관여하지 않는 거래이므로 정상 케이스). GRPCRP_dummy 내에서 두
법인의 기록을 교차 대사하는 것은 src/intercompany.py에서 처리한다.
"""

import os
import sys
import random
import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
from src import masters as m
from src import io_xlwings as xio

random.seed(20260901)

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
GRPCRP_PATH = os.path.join(DATA_DIR, "GRPCRP_dummy.xlsx")
SEP_PATH = os.path.join(DATA_DIR, "SEP_dummy.xlsx")
FX_PATH = os.path.join(DATA_DIR, "FX_dummy.xlsx")

# 더미데이터 '크기감'용 대략적 통화 스케일 (FX_dummy의 실제 회계환율과는 별개의 값)
UNITS_PER_USD = {
    "USD": 1, "EUR": 0.92, "GBP": 0.79, "CNY": 7.2, "JPY": 150, "VND": 25000,
    "IDR": 15600, "INR": 83, "MXN": 17, "PLN": 4.0, "THB": 35, "BRL": 5.0,
    "TRY": 32, "HKD": 7.8, "SGD": 1.35, "KRW": 1350,
}
NO_DECIMAL_CCY = {"JPY", "VND", "IDR", "KRW"}

MONTHS = [(y, mo) for y in range(2024, 2027) for mo in range(1, 13) if not (y == 2026 and mo > 6)]
MONTH_INDEX = {ym: i for i, ym in enumerate(MONTHS)}

BLANK5, BLANK2, BLANK1, BLANK10, BLANK100 = " " * 5, " " * 2, " " * 1, " " * 10, " " * 100

DOC_TYPE_BY_ACCT = {
    "0011010101": "DR", "0011010102": "DR", "0012010101": "DZ",
    "0021010101": "KR", "0021010102": "KR", "0022010101": "KZ", "0031010101": "SA",
    "0041010101": "DR", "0042010101": "DR", "0051010101": "KR",
    "0061010101": "SA", "0071010101": "SA", "0081010101": "KR", "0082010101": "KR",
}
DOC_PREFIX = {"DR": "50", "DZ": "50", "KR": "17", "KZ": "17", "SA": "11"}

GRPCRP_HEADER = ["ACCT_CD", "BOOK_AMT", "CORP_CD", "CRNC_CD", "DOCU_NO", "DTS_INSERT", "ICTR_CD",
                 "ICTR_TP", "IF_CD", "INIT_LOAD", "KUNNR", "LIFNR", "LINE_SQ", "MATKEY_VR", "MONAT",
                 "NAME1", "NOTE_DC", "SEND_SQ", "SETTL_YM", "ST_TRANS", "SYS_CD", "TCORP_CD",
                 "TRAN_AMT", "TRAN_DT", "TRCRNC_CD", "YEAR"]
SEP_HEADER = ["전표번호", "전기일", "GL계정", "채권채무명", "전표유형", "전표통화키", "[전표통화금액]", "BP_Key"]


def days_in_month(y, mo):
    nxt = datetime.date(y + (mo // 12), (mo % 12) + 1, 1)
    return (nxt - datetime.date(y, mo, 1)).days


def korean_date(y, mo, d):
    return f"{y}. {mo}. {d}."


def excel_serial(y, mo, d):
    return (datetime.date(y, mo, d) - datetime.date(1899, 12, 30)).days


def add_days_clamped(y, mo, d, add):
    dt = datetime.date(y, mo, d) + datetime.timedelta(days=add)
    return dt.year, dt.month, dt.day


def shift_month(y, mo, shift):
    idx = MONTH_INDEX[(y, mo)] + shift
    if idx < 0 or idx >= len(MONTHS):
        idx = MONTH_INDEX[(y, mo)] - shift
    return MONTHS[idx]


def round_ccy(v, ccy):
    return float(round(v)) if ccy in NO_DECIMAL_CCY else round(v, 2)


def random_local_amount(currency, usd_min, usd_max):
    usd = random.uniform(usd_min, usd_max)
    return round_ccy(usd * UNITS_PER_USD[currency], currency)


def load_fx_rate_lookup():
    with xio.excel_app() as app:
        fx = xio.read_sheet_df(app, FX_PATH)
    lut = {}
    for _, r in fx.iterrows():
        lut[(int(r["연월"]), str(r["통화코드"]))] = {
            "BS": float(r["기말환율(KRW)"]),
            "PL": float(r["누계평균환율(KRW)"]),
        }
    return lut


_counters = {"docu": 0, "line": 0, "sep_doc": 0}


def next_docu_no():
    _counters["docu"] += 1
    return 5100000000 + (_counters["docu"] * 37 + random.randint(0, 36)) % 99999999


def next_line_sq():
    _counters["line"] += random.randint(1, 40)
    return str(_counters["line"] % 999999999).zfill(10)


def next_send_sq():
    return str(random.randint(1, 9)).zfill(10)


def next_sep_doc_no(doc_type):
    _counters["sep_doc"] += 1
    prefix = DOC_PREFIX[doc_type]
    return int(prefix + str((_counters["sep_doc"] * 53 + random.randint(0, 52)) % 99999999).zfill(8))


OUTCOMES = ["MATCHED", "MISSING_2", "MISSING_1", "AMOUNT_DIFF", "TIMING_DIFF"]
OUTCOME_WEIGHTS = [80, 5, 5, 5, 5]


def pick_outcome():
    return random.choices(OUTCOMES, weights=OUTCOME_WEIGHTS)[0]


def generate_paired_amounts(rates, category, sign, currency1, currency2, yyyymm1, yyyymm2, outcome):
    """두 당사자(1,2)의 금액을 outcome에 따라 생성한다.

    MATCHED/TIMING_DIFF는 FX_dummy 실제환율로 1의 금액을 KRW로 환산한 뒤 2의 통화로
    역산해 대사 시 근사 일치하도록 만든다. 반환값 중 None은 그 쪽 데이터가 없음을 뜻한다.
    """
    usd_range = (5000, 300000) if category == "BS" else (1000, 120000)
    amt1 = amt2 = None
    if outcome in ("MATCHED", "TIMING_DIFF"):
        amt1 = random_local_amount(currency1, *usd_range) * sign
        krw_equiv = amt1 * rates[(yyyymm1, currency1)][category]
        amt2 = round_ccy(krw_equiv / rates[(yyyymm2, currency2)][category], currency2)
    elif outcome == "MISSING_2":
        amt1 = random_local_amount(currency1, *usd_range) * sign
    elif outcome == "MISSING_1":
        amt2 = random_local_amount(currency2, *usd_range) * sign
    elif outcome == "AMOUNT_DIFF":
        amt1 = random_local_amount(currency1, *usd_range) * sign
        amt2 = random_local_amount(currency2, *usd_range) * sign
    return amt1, amt2


def make_grpcrp_row(acct_cd, category, sign, corp, amt, y, mo, day, tcorp_cd, tcorp_name, yyyymm):
    ins_y, ins_mo, ins_d = add_days_clamped(y, mo, day, random.randint(1, 12))
    use_kunnr = category == "BS" and sign == 1
    use_lifnr = category == "BS" and sign == -1
    return {
        "ACCT_CD": acct_cd,
        "BOOK_AMT": amt,
        "CORP_CD": corp["CORP_CD"],
        "CRNC_CD": corp["CURRENCY"],
        "DOCU_NO": next_docu_no(),
        "DTS_INSERT": korean_date(ins_y, ins_mo, ins_d),
        "ICTR_CD": 2,
        "ICTR_TP": BLANK5,
        "IF_CD": BLANK2,
        "INIT_LOAD": BLANK1,
        "KUNNR": corp["KUNNR"] if use_kunnr else BLANK10,
        "LIFNR": corp["LIFNR"] if use_lifnr else BLANK10,
        "LINE_SQ": next_line_sq(),
        "MATKEY_VR": int(f"{y}{mo:02d}{day:02d}{random.randint(0, 9):03d}"),
        "MONAT": f"{mo:02d}",
        "NAME1": tcorp_name,
        "NOTE_DC": BLANK100,
        "SEND_SQ": next_send_sq(),
        "SETTL_YM": yyyymm,
        "ST_TRANS": "Y" if random.random() < 0.3 else "N",
        "SYS_CD": corp["CORP_CD"],
        "TCORP_CD": tcorp_cd,
        "TRAN_AMT": amt,
        "TRAN_DT": korean_date(y, mo, day),
        "TRCRNC_CD": corp["CURRENCY"],
        "YEAR": y,
    }


def make_sep_row(acct_cd, corp, amt, currency, y, mo, day):
    doc_type = DOC_TYPE_BY_ACCT[acct_cd]
    return {
        "전표번호": next_sep_doc_no(doc_type),
        "전기일": excel_serial(y, mo, day),
        "GL계정": acct_cd,
        "채권채무명": corp["CORP_NAME"],
        "전표유형": doc_type,
        "전표통화키": currency,
        "[전표통화금액]": amt,
        "BP_Key": corp["BP_KEY"],
    }


def main():
    rates = load_fx_rate_lookup()
    grpcrp_rows, sep_rows = [], []
    hq_outcome_counts = {}
    pair_outcome_counts = {}

    # ================= 본사(HQ)와의 거래 =================
    for corp in m.CORP_MASTER:
        for (y, mo) in MONTHS:
            yyyymm = y * 100 + mo
            for _ in range(random.randint(2, 5)):
                acct_cd, acct_meta = random.choice(list(m.ACCOUNT_MASTER.items()))
                category, sign = acct_meta["category"], acct_meta["sign"]

                outcome = pick_outcome()
                hq_outcome_counts[outcome] = hq_outcome_counts.get(outcome, 0) + 1

                g_day = random.randint(1, days_in_month(y, mo))
                sep_currency = "KRW" if random.random() < 0.8 else corp["CURRENCY"]
                if outcome == "TIMING_DIFF":
                    s_y, s_mo = shift_month(y, mo, random.choice([-1, 1]))
                else:
                    s_y, s_mo = y, mo
                s_yyyymm = s_y * 100 + s_mo
                s_day = random.randint(1, days_in_month(s_y, s_mo))

                grpcrp_amt, sep_amt = generate_paired_amounts(
                    rates, category, sign, corp["CURRENCY"], sep_currency, yyyymm, s_yyyymm, outcome,
                )

                if grpcrp_amt is not None:
                    grpcrp_rows.append(make_grpcrp_row(
                        acct_cd, category, sign, corp, grpcrp_amt, y, mo, g_day,
                        m.HQ_CORP_CD, m.HQ_CORP_NAME, yyyymm,
                    ))
                if sep_amt is not None:
                    sep_rows.append(make_sep_row(acct_cd, corp, sep_amt, sep_currency, s_y, s_mo, s_day))

    # ================= 법인간(HQ 비경유) 거래 =================
    # 매월 임의의 두 해외법인을 짝지어, 본사거래와 동일한 방식(80% 대응/20% 유형별 불일치)으로
    # 양쪽(A, B) 각자의 GRPCRP 기록을 생성한다. 본사 SEP 데이터에는 대응 내역을 만들지 않는다.
    for (y, mo) in MONTHS:
        yyyymm = y * 100 + mo
        for _ in range(random.randint(15, 25)):
            corp_a, corp_b = random.sample(m.CORP_MASTER, 2)
            acct_cd, acct_meta = random.choice(list(m.ACCOUNT_MASTER.items()))
            category, sign = acct_meta["category"], acct_meta["sign"]

            outcome = pick_outcome()
            pair_outcome_counts[outcome] = pair_outcome_counts.get(outcome, 0) + 1

            a_day = random.randint(1, days_in_month(y, mo))
            if outcome == "TIMING_DIFF":
                b_y, b_mo = shift_month(y, mo, random.choice([-1, 1]))
            else:
                b_y, b_mo = y, mo
            b_yyyymm = b_y * 100 + b_mo
            b_day = random.randint(1, days_in_month(b_y, b_mo))

            amt_a, amt_b = generate_paired_amounts(
                rates, category, sign, corp_a["CURRENCY"], corp_b["CURRENCY"], yyyymm, b_yyyymm, outcome,
            )

            if amt_a is not None:
                grpcrp_rows.append(make_grpcrp_row(
                    acct_cd, category, sign, corp_a, amt_a, y, mo, a_day,
                    corp_b["CORP_CD"], corp_b["CORP_NAME"], yyyymm,
                ))
            if amt_b is not None:
                grpcrp_rows.append(make_grpcrp_row(
                    acct_cd, category, sign, corp_b, amt_b, b_y, b_mo, b_day,
                    corp_a["CORP_CD"], corp_a["CORP_NAME"], b_yyyymm,
                ))

    print("GRPCRP rows:", len(grpcrp_rows))
    print("SEP rows:", len(sep_rows))
    print("HQ거래 유형 분포:", hq_outcome_counts)
    print("법인간거래 유형 분포:", pair_outcome_counts)

    grpcrp_df = pd.DataFrame(grpcrp_rows)[GRPCRP_HEADER]
    sep_df = pd.DataFrame(sep_rows)[SEP_HEADER]

    with xio.excel_app() as app:
        xio.write_df_sheet(app, grpcrp_df, GRPCRP_PATH, "GRPCRP_dummy")
        xio.write_df_sheet(app, sep_df, SEP_PATH, "SEP_dummy")

    print("Done.")


if __name__ == "__main__":
    main()
