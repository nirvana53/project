# -*- coding: utf-8 -*-
"""
FX_dummy.xlsx 재생성 스크립트 (통화별 월별 환율 데이터).

16개 통화(KRW 포함) x 30개월(2024-01~2026-06)에 대해 기말환율/월평균환율/누계평균환율
3종을 생성한다. 자산·부채 계정은 기말환율, 수익·비용 계정은 누계평균환율을 쓰도록 설계
되어 있다 (data/data.txt 3번 섹션 참고).

※ 최초 생성 시에는 임시 Node.js 스크립트로 만들고 사용 후 삭제했었는데, 프로젝트가
Python 기반으로 정리된 뒤 재현 가능하도록 이 스크립트를 tools/에 영구 보관한다.
GRPCRP_dummy/SEP_dummy(tools/generate_dummy_data.py)는 생성 시점에 이 파일을 읽어
매칭되는 거래 금액을 역산하므로, FX_dummy.xlsx를 다시 만들면 반드시 GRPCRP/SEP도
다시 생성해야 서로 어긋나지 않는다.
"""

import os
import sys
import random

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from src import io_xlwings as xio

random.seed(20260901 + 1)  # 거래 더미데이터(tools/generate_dummy_data.py) 시드와 구분되는 별도 시드

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
FX_PATH = os.path.join(DATA_DIR, "FX_dummy.xlsx")

CURRENCIES = [
    {"code": "KRW", "name": "한국 원",           "base": 1,      "decimals": 0, "fixed": True},
    {"code": "USD", "name": "미국 달러",         "base": 1350,   "decimals": 2},
    {"code": "EUR", "name": "유로",              "base": 1470,   "decimals": 2},
    {"code": "GBP", "name": "영국 파운드",       "base": 1710,   "decimals": 2},
    {"code": "CNY", "name": "중국 위안",         "base": 187.5,  "decimals": 2},
    {"code": "JPY", "name": "일본 엔(1엔)",      "base": 9.0,    "decimals": 4},
    {"code": "VND", "name": "베트남 동",         "base": 0.054,  "decimals": 6},
    {"code": "IDR", "name": "인도네시아 루피아", "base": 0.0865, "decimals": 6},
    {"code": "INR", "name": "인도 루피",         "base": 16.3,   "decimals": 4},
    {"code": "MXN", "name": "멕시코 페소",       "base": 79.4,   "decimals": 4},
    {"code": "PLN", "name": "폴란드 즈워티",     "base": 337.5,  "decimals": 2},
    {"code": "THB", "name": "태국 바트",         "base": 38.6,   "decimals": 4},
    {"code": "BRL", "name": "브라질 헤알",       "base": 270,    "decimals": 2},
    {"code": "TRY", "name": "튀르키예 리라",     "base": 42.2,   "decimals": 4},
    {"code": "HKD", "name": "홍콩 달러",         "base": 173.1,  "decimals": 2},
    {"code": "SGD", "name": "싱가포르 달러",     "base": 1000,   "decimals": 2},
]

MONTHS = [(y, mo) for y in range(2024, 2027) for mo in range(1, 13) if not (y == 2026 and mo > 6)]


def main():
    rows = []
    for ccy in CURRENCIES:
        prev_close = ccy["base"]
        ytd_sum, ytd_count, cur_year = 0.0, 0, None

        for (y, mo) in MONTHS:
            if cur_year != y:
                cur_year = y
                ytd_sum, ytd_count = 0.0, 0

            if ccy.get("fixed"):
                close_rate = ccy["base"]
                avg_rate = ccy["base"]
            else:
                close_rate = round(prev_close * (1 + random.uniform(-0.03, 0.03)), ccy["decimals"])
                avg_rate = round(((prev_close + close_rate) / 2) * (1 + random.uniform(-0.01, 0.01)), ccy["decimals"])

            ytd_sum += avg_rate
            ytd_count += 1
            cum_avg_rate = round(ytd_sum / ytd_count, ccy["decimals"])

            rows.append({
                "연월": y * 100 + mo,
                "통화코드": ccy["code"],
                "통화명": ccy["name"],
                "기준통화": "KRW",
                "기말환율(KRW)": close_rate,
                "월평균환율(KRW)": avg_rate,
                "누계평균환율(KRW)": cum_avg_rate,
            })
            prev_close = close_rate

    df = pd.DataFrame(rows).sort_values(["통화코드", "연월"]).reset_index(drop=True)
    print("FX rows:", len(df))

    with xio.excel_app() as app:
        xio.write_df_sheet(app, df, FX_PATH, "FX_dummy")
    print("Done.")


if __name__ == "__main__":
    main()
